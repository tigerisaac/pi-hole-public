Public code for the pi-hole, almost everything needed to run the project (besides the setup) is here and documentation is in a private repo as it contains sensitive data
<br> Note that you will need to provide a Groq API key to generate your own AI summaries
